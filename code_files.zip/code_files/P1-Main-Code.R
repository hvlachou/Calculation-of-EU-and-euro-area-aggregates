# Supply of statistical services in statistical methodology 
# Lot 1: Methodological support ''Support for calculation of EU aggregates with missing country values"
# Framework Contract No 2021.0364
# Ref. No.: ESTATMET3-000028-6000275881-REQ-01
#
# All research and codes by Fotis Papailias, (c) 2023/2024
# Input from Gian Luigi Mazzi on REG and RATIO approaches
# Input from Efthymios Xylagouras on boosting

# Clean memory and start from scratch
rm(list=ls(all=TRUE))

# Set the working directory where input files will be read from
# and output files will be saved
setwd("E:/Dropbox/ESTAT-AGG/Codes/qm/output/")

# Load the custom functions file
source("E:/Dropbox/ESTAT-AGG/Codes/qm/P2-functions.R")

# Load all necessary packages - MAKE SURE YOU HAVE INSTALLED THEM FIRST
load_multiple_libraries("forecast", "lubridate",
                        "randomForest", "xgboost",
                        "gbm", "kknn", "glmnet")

#######################################################################
#######################################################################
############################# User Input ##############################
# Data to be used in the analysis
fname <- "E:/Dropbox/ESTAT-AGG/Codes/qm/data/namq_10_gdp_working.csv"   # data file in the provided format

# Data to be used for the comparison
fname2 <- "E:/Dropbox/ESTAT-AGG/Codes/qm/data/namq_10_gdp_comparison.csv"   # data file in the provided format

# name for output
fnam3 <- "namq_10_gdp"

# Weights! We have 27 countries in the exact order as follows:
# "AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "EL"
# "ES", "FI", "FR", "HR", "HU", "IE", "IT", "LT", "LU",
# "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"
#
# Check the supplied "weights.csv" file
# column 1: no weights
# column 2: weights for Ind Pro
# column 3: weights for Retail Trade
# column 4: weights for Producer Prices in Industry
usr_w_file <- "E:/Dropbox/ESTAT-AGG/Codes/qm/weights.csv"
usr_w_column <- 2

# Which aggregate?
# 1: official eurostat (EU27_2020)
# 2: own calculated sum
usr_idx <- 1

# Stationarity transformation
# Some models can be applied directly to the level series
# the rest are applied to the stationary series which is then translated to levels
# what is the stationarity transformation to be used?
#
# Options:
# fdiff: first difference
# ldiff: log difference
usr_stransf <- "ldiff"

# Transformation to be used in the comparison
usr_stransf2 <- usr_stransf

# How many periods in the cross-validation?
# Set a unique number or insert a vector of dates in character format:
# usr_CV <- c("2018-01-01", "2019-01-01", "2020-01-01", "2021-01-01", "2022-01-01")
usr_CV <- 4*5+1  # plus one for the comparison series in the end

# Some machine learning methodologies, e.g. Random Forests
# have a natural element of "randomness" in their calculation.
# For example, RF has three random elements:
#
# 1. The shuffling of the data when a new tree is trained
# 2. The shuffling of the features picked at random when building each node
# 3. The training data passed to .fit()
#
# To control that "randomness" there are two ways.
# A) the exact way is to set random.seed(1234) so that always the same routes are used
# B) the approximate way which is to run a sort of "stoch/sim/bagging" and take the average
#
# We consider (B) above and the parameter below
# controls the times we run the forecasts before averaging them
usr_nB <- 200

# Combination of countries/members with missing values
usr_MV <- list(c("MT"),
                c("MT", "LU"),
                c("MT", "LU", "HR"),
                c("MT", "SK", "CZ", "EL"),
                c("MT", "EL", "IE", "DK"),
                c("MT", "AT"),
                c("EL", "AT", "NL", "ES"),
                c("AT", "NL", "ES"),
                c("ES"),
                c("FR"),
                c("IT"),
                c("DE"),
                c("ES", "IT"),
                c("ES", "IT", "FR"),
                c("IT", "FR", "DE"))
########################## End of User Input ##########################
#######################################################################
#######################################################################
############## DO NOT CHANGE ANY LINES FROM THIS POINT ################

# Load the data and manipulate its format to a matrix()
data <- read.csv(fname, header=TRUE)
d <- data[,1]
data <- apply(data[,2:NCOL(data)], 2, as.numeric)
rownames(data) <- d

if(NROW(usr_CV)==1){
  usr_CV <- d[(NROW(d)-usr_CV+1):NROW(d)]
}

# Load the data for comparison and manipulate to a matrix
data2 <- read.csv(fname2, header=TRUE)
d2 <- data2[,1]
data2 <- apply(data2[,2:NCOL(data2)], 2, as.numeric)
rownames(data2) <- d2

# Some checks
if(NROW(usr_CV)<=1){stop("You do not have enough evaluation periods in your cross-validation!")}
if((usr_stransf!="fdiff") & (usr_stransf!="ldiff")){stop("You have not specified a suitable stationarity transformation!")}
nB <- usr_nB

# load the weights
wdata <- read.csv(usr_w_file, header=TRUE)
cnames <- wdata[,1]
wdata <- apply(wdata[,2:NCOL(wdata)], 2, as.numeric)
rownames(wdata) <- cnames

# careful here, we are creating a global variable!
w_w <- wdata[,usr_w_column]

# split the data
# Levels
data_c <- data[,1:(NCOL(data)-2)] # individual countries
data_s <- data[,(NCOL(data)-1):NCOL(data)]  # aggregates
data2_s <- data2[,(NCOL(data2)-1):NCOL(data2)]# aggregates for comparison

# Make Stationary
if(usr_stransf=="fdiff"){
  data_cD <- diff(data_c)
  data_sD <- diff(data_s)
}
if(usr_stransf=="ldiff"){
  data_cD <- diff(log(data_c))
  data_sD <- diff(log(data_s))
}

# Prepare the lists to save the output across all cases
all_MAE <- list()
all_MSE <- list()
all_RMSE <- list()
all_est <- list()
all_est2 <- list()
all_true <- list()
all_err <- list()
all_CR1 <- list()
all_CR3 <- list()
all_CR5 <- list()
all_CR1avg <- list()
all_CR3avg <- list()
all_CR5avg <- list()
all_CR1avgM <- matrix(NA, 38, NROW(usr_MV))
all_CR3avgM <- all_CR1avgM
all_CR5avgM <- all_CR1avgM

# Loop across your MV cases
for(iMV in 1:NROW(usr_MV))
{
  usr_MVi <- usr_MV[[iMV]]
  
  # Methodologies/Models
  # Explanations:
  #  -- "LV" prefix means that the method can and is applied
  #     directly to the levels
  #
  #  -- "S" prefix means that the method is applied directly to the stationary
  #     series but it is translated to the levels
  #
  # So, in all methods/models, all evaluation is performed in levels
  mnames <- c("LV_NAIVE", "LV_Avg2", "LV_Avg4", "LV_BATS", "LV_ETS",
              "LV_NNETAR", "LV_SPLINE", "LV_THETA", "LV_AR1", "LV_ARIMA", "LV_TREND",
              "LV_REG", "LV_RATIO_LAST", "LV_RATIO_HAVG",
              "D_NAIVE", "D_Avg2", "D_Avg4", "D_BATS", "D_ETS",
              "D_NNETAR", "D_SPLINE", "D_THETA", "D_AR1", "D_ARMA", "D_TREND",
              "D_REG", "D_RATIO_LAST", "D_RATIO_HAVG",
              
              "D_RF", "D_XGBoost", "D_GB", 
              "D_KNN", "D_Lasso", "D_AdaLasso", "D_Ridge", "D_AdaRidge", 
              "D_ElastNet", "D_AdaElastNet")
  est_out <- matrix(NA, NROW(data_c), NROW(mnames))
  rownames(est_out) <- rownames(data_c)
  colnames(est_out) <- mnames
  
  for(i in 1:NROW(usr_CV))
  {
    iy <- usr_CV[i]
    
    # Data we "see" up to now
    x_c <- data_c[1:which(rownames(data_c)==iy),]
    x_s <- data_s[1:which(rownames(data_s)==iy),]
    x_cD <- data_cD[1:which(rownames(data_cD)==iy),]
    x_sD <- data_sD[1:which(rownames(data_sD)==iy),]
    
    # for the sums, we don't have the latest sum as there are some vals missing
    x_s[NROW(x_s),] <- NA
    x_sD[NROW(x_sD),] <- NA
    
    # also, add missing values to the specified countries
    x_c[NROW(x_c), usr_MVi] <- NA
    x_cD[NROW(x_cD), usr_MVi] <- NA
    
    # Fix the missing values and calculate the aggregate
    
    # Naive in Levels
    im <- 1
    outs <- do_Naive(x_c)
    est_out[iy,im] <- outs$agg
    
    # Avg2 in Levels
    im <- im+1
    outs <- do_Avg(x_c, 2)
    est_out[iy,im] <- outs$agg
    
    # Avg4 in Levels
    im <- im+1;
    outs <- do_Avg(x_c, 4)
    est_out[iy,im] <- outs$agg
    
    # BATS in Levels
    im <- im+1
    outs <- do_BATS(x_c)
    est_out[iy,im] <- outs$agg
    
    # ETS in Levels
    im <- im+1
    outs <- do_ETS(x_c)
    est_out[iy,im] <- outs$agg
    
    # NNETAR in Levels
    im <- im+1
    outs <- do_NNETAR(x_c)
    est_out[iy,im] <- outs$agg
    
    # SPLINE in Levels
    im <- im+1
    outs <- do_SPLINE(x_c)
    est_out[iy,im] <- outs$agg
    
    # THETA in Levels
    im <- im+1
    outs <- do_THETA(x_c)
    est_out[iy,im] <- outs$agg
    
    # AR1 in Levels
    im <- im+1
    outs <- do_AR1(x_c, c(1,1,0))
    est_out[iy,im] <- outs$agg
    
    # ARIMA in Levels
    im <- im+1
    outs <- do_ARIMA(x_c)
    est_out[iy,im] <- outs$agg
    
    # TREND in Levels
    im <- im+1
    outs <- do_TREND(x_c)
    est_out[iy,im] <- outs$agg
    
    # Reg in Levels
    im <- im+1
    outs <- do_REG_PAR(x_c, x_s[,usr_idx])
    est_out[iy,im] <- outs
    
    # Ratio1 in Levels
    im <- im+1
    outs <- do_RATIO1(x_c, x_s[,usr_idx])
    est_out[iy,im] <- outs
    
    # Ratio2 in Levels
    im <- im+1
    outs <- do_RATIO2(x_c, x_s[,usr_idx])
    est_out[iy,im] <- outs
    
    # Now, we do the same for the stationary, and then translated in levels
    ##################################################################
  
    # Last observed in levels?
    x_c_L <- na.omit(x_c)
    x_c_L <- x_c_L[NROW(x_c_L),]
    x_s_L <- na.omit(x_s[,usr_idx])
    x_s_L <- x_s_L[NROW(x_s_L)]
    
    # Naive in Diff
    im <- im+1
    outs <- do_Naive(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # Avg2 in Diff
    im <- im+1
    outs <- do_Avg(x_cD, 2)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # Avg4 in Diff
    im <- im+1
    outs <- do_Avg(x_cD, 4)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # BATS in Diff
    im <- im+1
    outs <- do_BATS(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ETS in Diff
    im <- im+1
    outs <- do_ETS(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # NNETAR in Diff
    im <- im+1
    outs <- do_NNETAR(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # SPLINE in Diff
    im <- im+1
    outs <- do_SPLINE(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # THETA in Diff
    im <- im+1
    outs <- do_THETA(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # AR1 in Diff
    im <- im+1
    outs <- do_AR1(x_cD, c(1,0,0))
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ARMA in Diff
    im <- im+1
    outs <- do_ARIMA(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # TREND in Diff
    im <- im+1
    outs <- do_TREND(x_cD)
    outs <- translate_levels(outs$indiv, x_c_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # REG in Diff
    im <- im+1
    outs <- do_REG_PAR(x_cD, x_sD[,usr_idx])
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # RATIO1 in Diff
    im <- im+1
    outs <- do_RATIO1(x_cD, x_sD[,usr_idx])
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # RATIO2 in Diff
    im <- im+1
    outs <- do_RATIO2(x_cD, x_sD[,usr_idx])
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # Random Forests in Diff
    im <- im+1
    outs <- do_RF_nB(x_cD, x_sD[,usr_idx], nB)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # XGBoost in Diff
    im <- im+1
    outs <- do_XGB(x_cD, x_sD[,usr_idx], nB)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # GB
    im <- im+1
    outs <- do_GB_nB(x_cD, x_sD[,usr_idx], nB)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # KNNReg in Diff
    im <- im+1
    outs <- do_KNN(x_cD, x_sD[,usr_idx])
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # LASSO in Diff
    im <- im+1
    outs <- do_PEN(x_cD, x_sD[,usr_idx], 1)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ADALASSO in Diff
    im <- im+1
    outs <- do_ADAPEN(x_cD, x_sD[,usr_idx], 1)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # RIDGE in Diff
    im <- im+1
    outs <- do_PEN(x_cD, x_sD[,usr_idx], 0)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ADARIDGE in Diff
    im <- im+1
    outs <- do_ADAPEN(x_cD, x_sD[,usr_idx], 0)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ELNET in Diff
    im <- im+1
    outs <- do_PEN(x_cD, x_sD[,usr_idx], 0.5)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    # ADAELNET in Diff
    im <- im+1
    outs <- do_ADAPEN(x_cD, x_sD[,usr_idx], 0.5)
    outs <- translate_levels(outs, x_s_L, usr_stransf)
    est_out[iy,im] <- outs$agg
    
    cat("Now done", i, "of ", NROW(usr_CV), "and", iMV, "of", NROW(usr_MV), "\n")
  }
  
  # estimates
  est_out <- na.omit(est_out)
  
  # transform the estimates to the comparison series
  if(usr_stransf2=="fdiff"){
    est_out2 <- diff(est_out)
  }
  if(usr_stransf2=="ldiff"){
    est_out2 <- diff(log(est_out))*100  # multiply by 100 because ESTAT is already by 100
  }
  
  # true comes from the comparison series ;-)
  Y <- data2_s[rownames(est_out2),usr_idx]
  Ydec <- nchar(strsplit(as.character(Y[1]), "\\.")[[1]][2])
  est_out2 <- round(est_out2, Ydec)
  
  # error
  e <- Y-est_out2
  
  # MAE, MSE, RMSE
  MAE <- colMeans(abs(e))
  MSE <- colMeans(e^2)
  RMSE <- sqrt(MSE)
  
  # calculate the 1%, 3%, 5% symmetric intervals as in the call
  # "...Conditions will be identified so that the EU aggregate
  # calculated with missing data would no
  #
  # But we are working with percentage rates, so the comparison will be done
  # additively as:
  # x +/- 0.1% (i.e. 0.001 in decimals)
  # x +/- 0.3% (i.e. 0.003 in decimals)
  # x +/- 0.5% (i.e. 0.005 in decimals)
  est1_LB <- est_out2-0.1
  est3_LB <- est_out2-0.3
  est5_LB <- est_out2-0.5
  est1_UB <- est_out2+0.1
  est3_UB <- est_out2+0.3
  est5_UB <- est_out2+0.5
  
  # Calculate the coverage rates
  CR1 <- est_out2*0
  CR3 <- CR5 <- CR1
  
  for(i in 1:NROW(Y))
  {
    y <- Y[i]
    for(j in 1:NCOL(est_out2))
    {
      xL <- est1_LB[i,j]
      xU <- est1_UB[i,j]
      if(y>=xL & y<=xU){
        CR1[i,j] <- 1
      }
      
      xL <- est3_LB[i,j]
      xU <- est3_UB[i,j]
      if(y>=xL & y<=xU){
        CR3[i,j] <- 1
      }
      
      xL <- est5_LB[i,j]
      xU <- est5_UB[i,j]
      if(y>=xL & y<=xU){
        CR5[i,j] <- 1
      }
    }
  }
  
  # Calculate the percentage of times
  CR1_avg <- colMeans(CR1)
  CR3_avg <- colMeans(CR3)
  CR5_avg <- colMeans(CR5)
  
  # save all output
  all_MAE <- c(all_MAE, list(MAE))
  all_MSE <- c(all_MSE, list(MSE))
  all_RMSE <- c(all_RMSE, list(RMSE))
  all_est <- c(all_est, list(est_out))
  all_est2 <- c(all_est2, list(est_out2))
  all_true <- c(all_true, list(Y))
  all_err <- c(all_err, list(e))
  all_CR1 <- c(all_CR1, list(CR1))
  all_CR3 <- c(all_CR3, list(CR3))
  all_CR5 <- c(all_CR5, list(CR5))
  all_CR1avg <- c(all_CR1avg, list(CR1_avg))
  all_CR3avg <- c(all_CR3avg, list(CR3_avg))
  all_CR5avg <- c(all_CR5avg, list(CR5_avg))
  all_CR1avgM[,iMV] <- CR1_avg
  all_CR3avgM[,iMV] <- CR3_avg
  all_CR5avgM[,iMV] <- CR5_avg
}

# flatten the case names
MVflat <- NULL
for(i in 1:NROW(usr_MV))
{
  zx <- usr_MV[[i]]
  zxnew <- NULL
  if(NROW(zx)>1){
    zxnew <- zx[1]
    for(ii in 2:NROW(zx))
    {
      zxnew <- paste(zxnew, zx[ii], sep=", ")
    }
  }else{
    zxnew <- zx
  }
  MVflat <- c(MVflat, zxnew)
}

rownames(all_CR1avgM) <- rownames(all_CR3avgM) <- rownames(all_CR5avgM) <- mnames
colnames(all_CR1avgM) <- colnames(all_CR3avgM) <- colnames(all_CR5avgM) <- MVflat

write.csv(all_CR1avgM, paste(fnam3, "_CR1.csv", sep=""))
write.csv(all_CR3avgM, paste(fnam3, "_CR3.csv", sep=""))
write.csv(all_CR5avgM, paste(fnam3, "_CR5.csv", sep=""))
save.image(paste(fnam3, ".RData", sep=""))

