load_multiple_libraries <- function(...) {
  sapply(sapply(match.call(), as.character)[-1], require, character.only = TRUE)
}

make_groups <- function(Z)
{
  # z <- colMeans(Z)
  w <- 1:NROW(Z)
  w <- w/sum(w)
  W <- matrix(w, NROW(Z), NCOL(Z))
  z <- colSums(Z*W)
  
  if(usr_btype=="high"){
    z <- sort(z, decreasing=FALSE)
  }
  if(usr_btype=="low"){
    z <- sort(z, decreasing=TRUE)
  }
  z <- as.matrix(z)
  zr <- rownames(z)
  z1 <- zr[1:9]
  z2 <- zr[10:18]
  z3 <- zr[19:27]
  return(list(small=z1, medium=z2, large=z3))
}

do_Naive <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    zzf <- zz
    zzf[zm] <- zc[NROW(zc)]
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_Avg <- function(Z, avper)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    zzf <- zz
    zzf[zm] <- mean(zc[(NROW(zc)-avper+1):NROW(zc)])
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_BATS <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    out <- bats(zc)
    outf <- forecast(out, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_ETS <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    out <- ets(zc)
    outf <- forecast(out, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_NNETAR <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    out <- nnetar(zc)
    outf <- forecast(out, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_SPLINE <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    outf <- splinef(zc, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_THETA <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    outf <- thetaf(zc, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_ARIMA <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    out <- auto.arima(zc)
    outf <- forecast(out, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_AR1 <- function(Z, Zord)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zc <- na.omit(zz)
    out <- NULL
    out <- try(arima(zc, order=Zord), silent=TRUE)
    if((is.null(out)==TRUE)|(NROW(out)==1)){
      out <- try(arima(zc, order=Zord, method="ML"), silent=TRUE)
    }
    if((is.null(out)==TRUE)|(NROW(out)==1)){
      out <- try(arima(zc, order=c(1,1,0)), silent=TRUE)
    }
    if((is.null(out)==TRUE)|(NROW(out)==1)){
      out <- try(arima(zc, order=c(1,1,0), method="ML"), silent=TRUE)
    }
    if((is.null(out)==TRUE)|(NROW(out)==1)){
      stop("error in AR(1)")
    }

    outf <- forecast(out, h=NROW(zm))
    zzf <- zz
    zzf[zm] <- as.numeric(outf$mean)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_TREND <- function(Z)
{
  zw <- which(colSums(is.na(Z))==1)
  Zf <- Z
  for(i in zw)
  {
    zz <- Z[,i]
    zm <- which(is.na(zz))
    zx <- 1:NROW(zz)
    out <- lm(zz~zx)
    a <- coef(out)[1]
    b <- coef(out)[2]
    outf <- a + b*zx[zm]
    zzf <- zz
    zzf[zm] <- as.numeric(outf)
    Zf[,i] <- zzf
  }
  Zf2 <- sum(w_w*Zf[NROW(Zf),])
  return(list(agg=Zf2, indiv=Zf[NROW(Zf),]))
}

do_REG_HD <- function(Z, Zs)
{
  zw <- which(colSums(is.na(Z))==1)
  P <- na.omit(Z)
  Ps <- na.omit(Zs)
  Y <- Ps
  X <- P[,-zw]
  Xout <- Z[NROW(Z), -zw]
  out <- lm(Y~X)
  allc <- coef(out)
  a <- allc[1]
  b <- allc[2:NROW(allc)]
  outf <- a + b%*%Xout
  return(outf)
}

do_REG_PAR <- function(Z, Zs)
{
  zw <- which(colSums(is.na(Z))==1)
  Y <- Zs
  X <- rowSums(Z[,-zw])
  Xout <- X[NROW(X)]
  out <- lm(Y~X)
  allc <- coef(out)
  a <- allc[1]
  b <- allc[2:NROW(allc)]
  outf <- a + b%*%Xout
  return(outf)
}

do_RATIO1 <- function(Z, Zs)
{
  zw <- which(colSums(is.na(Z))==1)
  Y <- Zs
  X <- rowSums(Z[,-zw])
  rr <- na.omit(Y/X)
  rr <- rr[NROW(rr)]
  Xout <- X[NROW(X)]
  outf <- rr*Xout
  return(outf)
}

do_RATIO2 <- function(Z, Zs)
{
  zw <- which(colSums(is.na(Z))==1)
  Y <- Zs
  X <- rowSums(Z[,-zw])
  rr <- na.omit(Y/X)
  rr <- mean(rr)
  Xout <- X[NROW(X)]
  outf <- rr*Xout
  return(outf)
}

translate_levels <- function(KEST, KLAS, KTYP)
{
  if(KTYP=="fdiff"){
    fout <- KLAS+KEST
  }
  if(KTYP=="ldiff"){
    fout <- exp(log(KLAS)+KEST)
  }
  return(list(agg=sum(w_w*fout), indiv=fout))
}

translate_levels2 <- function(KEST, KLAS, KTYP)
{
  if(KTYP=="fdiff"){
    fout <- KLAS+KEST
  }
  if(KTYP=="ldiff"){
    fout <- exp(log(KLAS)+KEST)
  }
  return(list(agg=sum(fout), indiv=fout))
}

do_RF <- function(Z, Zs)
{
   zw <- which(colSums(is.na(Z))>=1)
   Y <- Zs
   Y_na <- which(is.na(Y))
   X <- Z[,-zw]
   X <- scale(X)
   dataf <- data.frame(X, Y)
   model <- randomForest(Y ~ ., data=dataf[-Y_na, ],
                          localImp=TRUE)
   outf <- predict(model, newdata=dataf[Y_na, -NCOL(dataf)])
   outf <- as.numeric(outf)
   return(outf)
}

do_RF_nB <- function(Z, Zs, NB)
{
	est <- rep(NA, NB)
	for(i in 1:NB)
	{
		est[i] <- do_RF(Z, Zs)
	}
	outf <- mean(est)
}

do_XGB <- function(Z, Zs, NB)
{
  zw <- which(colSums(is.na(Z))>=1)
  Y <- Zs
  Y_na <- which(is.na(Y))
  X <- Z[,-zw]
  X <- scale(X)
  dataxg <- xgb.DMatrix(data=X[-Y_na,], label=Y[-Y_na])
  model <- xgboost(data=dataxg, nrounds=NB, 
                   objective = "reg:squarederror",
                   print_every_n=NB)
  outf <- predict(model, newdata = t(X[Y_na,]))
  outf <- as.numeric(outf)
  return(outf)
}

do_GB <- function(Z, Zs, NB)
 {
    zw <- which(colSums(is.na(Z))>=1)
    Y <- Zs
    Y_na <- which(is.na(Y))
    X <- Z[,-zw]
    X <- scale(X)
    dataf <- data.frame(X, Y)
    model <- gbm(Y ~ ., data=dataf[-Y_na, ],
                 distribution="gaussian",
                 n.trees=NB, n.minobsinnode=1)
    outf <- predict(model, newdata=dataf[Y_na, -NCOL(dataf)], n.trees=NB)
    outf <- as.numeric(outf)
    return(outf)
}

do_GB_nB <- function(Z, Zs, NB)
{
	est <- rep(NA, NB)
	for(i in 1:NB)
	{
		est[i] <- do_GB(Z, Zs, NB)
	}
	outf <- mean(est)
}

do_KNN <- function(Z, Zs)
{
  zw <- which(colSums(is.na(Z))>=1)
  Y <- Zs
  Y_na <- which(is.na(Y))
  X <- Z[,-zw]
  X <- scale(X)
  dataf <- data.frame(X, Y)
  model <- kknn(formula=Y ~ ., train = dataf[-Y_na, ],
                test = dataf[Y_na, -NCOL(dataf)],
                kernel = "optimal")
  outf <- fitted(model)
  outf <- as.numeric(outf)
  return(outf)
}

#ALPHA = 1: Lasso
# ALPHA = 0: Ridge
# ALPHA inbetween, ELAST NET
do_PEN <- function(Z, Zs, ALPHA)
{
zw <- which(colSums(is.na(Z))>=1)
  Y <- Zs
  Y_na <- which(is.na(Y))
  X <- Z[,-zw]
  X <- scale(X)
  Xout <- X[NROW(X),]
  Nnona <- NROW(Y[-Y_na])
  cv_fit <- cv.glmnet(x=X[-Y_na,], y=Y[-Y_na],
                      alpha=ALPHA, nfolds=Nnona,
                      standardize=FALSE,
                      intercept=TRUE)
  lmin <- cv_fit$lambda.min
  allc <- coef(cv_fit, lmin)
  a <- allc[1]
  b <- allc[2:NROW(allc)]
  outf <- a + b%*%Xout
  outf <- as.numeric(outf)
  return(outf)
}

do_ADAPEN <- function(Z, Zs, ALPHA)
{
    zw <- which(colSums(is.na(Z))>=1)
    Y <- Zs
    Y_na <- which(is.na(Y))
    X <- Z[,-zw]
    X <- scale(X)
    Xout <- X[NROW(X),]
    Nnona <- NROW(Y[-Y_na])
    
    # Ridge
    cv_fit <- cv.glmnet(x=X[-Y_na,], y=Y[-Y_na],
                        alpha=0, nfolds=Nnona,
                        standardize=FALSE,
                        intercept=TRUE)
    lmin <- cv_fit$lambda.min
    allc <- coef(cv_fit, lmin)
    allc <- allc[-1]
    penalty_factors <- 1 / abs(allc)
    
    #AdaLasso
    cv_fit <- cv.glmnet(x=X[-Y_na,], y=Y[-Y_na],
                        alpha=ALPHA, nfolds=Nnona,
                        standardize=FALSE,
                        intercept=TRUE,
                        penalty.factor=penalty_factors)
    lmin <- cv_fit$lambda.min
    allc <- coef(cv_fit, lmin)
    a <- allc[1]
    b <- allc[2:NROW(allc)]
    outf <- a + b%*%Xout
    outf <- as.numeric(outf)
    return(outf)
}
